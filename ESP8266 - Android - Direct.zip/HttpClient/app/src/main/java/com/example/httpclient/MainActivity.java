package com.example.httpclient;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class MainActivity extends AppCompatActivity {

    String serverResponse;
    MyClientTask onLedTask;
    Button firstLED, secondLED;
    ToggleButton toggleButton, toggleButton2, toggleButton3, toggleButton4, toggleButton5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toggleButton = (ToggleButton) findViewById(R.id.toggleButton);
        toggleButton2 = (ToggleButton) findViewById(R.id.toggleButton2);
        toggleButton3 = (ToggleButton) findViewById(R.id.toggleButton3);
        toggleButton4 = (ToggleButton) findViewById(R.id.toggleButton4);
        toggleButton5 = (ToggleButton) findViewById(R.id.toggleButton5);

        toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    onLedTask = new MyClientTask("4/on");
                    onLedTask.execute();
                } else {
                    onLedTask = new MyClientTask("4/off");
                    onLedTask.execute();
                }
            }
        });

        toggleButton2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    onLedTask = new MyClientTask("12/on");
                    onLedTask.execute();
                } else {
                    onLedTask = new MyClientTask("12/off");
                    onLedTask.execute();
                }
            }
        });

        toggleButton3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    onLedTask = new MyClientTask("13/on");
                    onLedTask.execute();
                } else {
                    onLedTask = new MyClientTask("13/off");
                    onLedTask.execute();
                }
            }
        });

        toggleButton4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    onLedTask = new MyClientTask("14/on");
                    onLedTask.execute();
                } else {
                    onLedTask = new MyClientTask("14/off");
                    onLedTask.execute();
                }
            }
        });


        toggleButton5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    onLedTask = new MyClientTask("16/on");
                    onLedTask.execute();
                } else {
                    onLedTask = new MyClientTask("16/off");
                    onLedTask.execute();
                }
            }
        });
    }

    public class MyClientTask extends AsyncTask<String, Void, String> {

        String addressValue;

        public MyClientTask(String address) {
            this.addressValue = address;
        }

        @Override
        protected String doInBackground(String... params) {

            final StringBuffer chain = new StringBuffer("");
            String serverResponse = "";
            final String p = "http://192.168.4.1/" + addressValue;
            String line = "";

            try {
                URL url = new URL(p);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));

                while ((line = rd.readLine()) != null) {
                    chain.append(line);
                }
            } catch (IOException e) {
                e.printStackTrace();
                serverResponse = e.getMessage();
            }

            return serverResponse;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
    }
}

//String p = "http://192.168.4.1/OnLED1";
//    try {
//            URL url = new URL(p);
//            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//            connection.setRequestMethod("GET");
//            connection.connect();
//            } catch (IOException e) {
//            e.printStackTrace();
//            }